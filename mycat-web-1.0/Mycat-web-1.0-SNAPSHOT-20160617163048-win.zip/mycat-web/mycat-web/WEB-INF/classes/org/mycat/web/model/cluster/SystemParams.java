package org.mycat.web.model.cluster;

public class SystemParams {
	
	private String defaultsqlparser;
	
	private Integer severPort;
	
	private String sequncehandlertype;

	public String getDefaultsqlparser() {
		return defaultsqlparser;
	}

	public void setDefaultsqlparser(String defaultsqlparser) {
		this.defaultsqlparser = defaultsqlparser;
	}

	public Integer getSeverPort() {
		return severPort;
	}

	public void setSeverPort(Integer severPort) {
		this.severPort = severPort;
	}

	public String getSequncehandlertype() {
		return sequncehandlertype;
	}

	public void setSequncehandlertype(String sequncehandlertype) {
		this.sequncehandlertype = sequncehandlertype;
	}


	
	

}
