package org.mycat.web.model.cluster;

public class DataNode {
	
	private String name;
	private String dataHost;
	private String database;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDataHost() {
		return dataHost;
	}
	public void setDataHost(String dataHost) {
		this.dataHost = dataHost;
	}
	public String getDatabase() {
		return database;
	}
	public void setDatabase(String database) {
		this.database = database;
	}
	

}
